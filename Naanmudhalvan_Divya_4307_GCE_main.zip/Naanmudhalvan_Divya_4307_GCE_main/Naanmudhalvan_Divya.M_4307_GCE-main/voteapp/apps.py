from django.apps import AppConfig


class VoteappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'voteapp'
